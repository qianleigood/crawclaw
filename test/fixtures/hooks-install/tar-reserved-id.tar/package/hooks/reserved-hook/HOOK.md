---
name: reserved-hook
description: reserved-hook
metadata: {"crawclaw":{"events":["command:new"]}}
---

# Hook