---
name: evil-hook
description: evil-hook
metadata: {"crawclaw":{"events":["command:new"]}}
---

# Hook