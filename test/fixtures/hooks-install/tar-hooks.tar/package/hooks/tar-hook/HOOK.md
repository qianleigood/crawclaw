---
name: tar-hook
description: tar-hook
metadata: {"crawclaw":{"events":["command:new"]}}
---

# Hook